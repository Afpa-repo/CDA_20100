create
    definer = root@localhost procedure delai_moyen(IN commande int)
BEGIN

SELECT ROUND(AVG(DATEDIFF(cmd_fact_date,cmd_date))) AS "Délai moyen de livraison en jours"
FROM commande
WHERE cmd_id = commande;

END;

