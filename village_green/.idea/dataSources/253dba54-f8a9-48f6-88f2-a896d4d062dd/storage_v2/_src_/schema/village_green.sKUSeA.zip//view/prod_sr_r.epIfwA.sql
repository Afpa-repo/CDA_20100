create view prod_sr_r as
select `village_green`.`produit`.`pro_id`             AS `pro_id`,
       `village_green`.`produit`.`pro_lib`            AS `pro_lib`,
       `village_green`.`produit`.`pro_descr`          AS `pro_descr`,
       `village_green`.`produit`.`pro_prix_achat`     AS `pro_prix_achat`,
       `village_green`.`produit`.`pro_photo`          AS `pro_photo`,
       `village_green`.`produit`.`pro_stock`          AS `pro_stock`,
       `village_green`.`produit`.`pro_actif`          AS `pro_actif`,
       `village_green`.`produit`.`pro_s_rub_id`       AS `pro_s_rub_id`,
       `village_green`.`sous_rubrique`.`s_rub_id`     AS `s_rub_id`,
       `village_green`.`sous_rubrique`.`s_rub_nom`    AS `s_rub_nom`,
       `village_green`.`sous_rubrique`.`s_rub_rub_id` AS `s_rub_rub_id`,
       `village_green`.`rubrique`.`rub_id`            AS `rub_id`,
       `village_green`.`rubrique`.`rub_nom`           AS `rub_nom`
from ((`village_green`.`produit` join `village_green`.`sous_rubrique`)
         join `village_green`.`rubrique`)
where ((`village_green`.`rubrique`.`rub_id` = `village_green`.`sous_rubrique`.`s_rub_id`) and
       (`village_green`.`sous_rubrique`.`s_rub_id` = `village_green`.`produit`.`pro_s_rub_id`));

