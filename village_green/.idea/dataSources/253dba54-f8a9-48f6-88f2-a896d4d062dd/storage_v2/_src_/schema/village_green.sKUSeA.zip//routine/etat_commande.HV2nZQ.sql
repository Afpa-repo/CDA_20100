create
    definer = root@localhost procedure etat_commande(IN livr varchar(250))
BEGIN

SELECT liv_id, liv_date, liv_cmd_id, liv_etat AS "Commandes en cours de livraison"
FROM livraison
WHERE liv_etat = livr;

END;

