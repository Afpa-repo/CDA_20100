create view produits_fournisseurs as
select `village_green`.`produit`.`pro_id`         AS `pro_id`,
       `village_green`.`produit`.`pro_lib`        AS `pro_lib`,
       `village_green`.`produit`.`pro_descr`      AS `pro_descr`,
       `village_green`.`produit`.`pro_prix_achat` AS `pro_prix_achat`,
       `village_green`.`produit`.`pro_photo`      AS `pro_photo`,
       `village_green`.`produit`.`pro_stock`      AS `pro_stock`,
       `village_green`.`produit`.`pro_actif`      AS `pro_actif`,
       `village_green`.`produit`.`pro_s_rub_id`   AS `pro_s_rub_id`,
       `village_green`.`envoie`.`env_four_id`     AS `env_four_id`,
       `village_green`.`envoie`.`env_pro_id`      AS `env_pro_id`,
       `village_green`.`envoie`.`env_qte`         AS `env_qte`,
       `village_green`.`fournisseur`.`four_id`    AS `four_id`,
       `village_green`.`fournisseur`.`four_nom`   AS `four_nom`,
       `village_green`.`fournisseur`.`four_type`  AS `four_type`
from ((`village_green`.`produit` join `village_green`.`envoie`)
         join `village_green`.`fournisseur`)
where ((`village_green`.`produit`.`pro_id` = `village_green`.`envoie`.`env_pro_id`) and
       (`village_green`.`envoie`.`env_four_id` = `village_green`.`fournisseur`.`four_id`));

